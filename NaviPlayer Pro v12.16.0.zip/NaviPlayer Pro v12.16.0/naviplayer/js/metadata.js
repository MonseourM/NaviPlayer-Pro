import { basename, normalizePath, extension } from './utils.js';
import { readMetadataCache, writeMetadataCache } from './storage.js';
import { state } from './state.js';
import { parseBlob } from './vendor/music-metadata.bundle.js';

const METADATA_CACHE_VERSION = 'v1215meta5';
const SCAN_RANK = { quick: 0, standard: 1, deep: 2 };
export const metadataScanModes = Object.freeze({
  quick: { label: 'Quick', description: 'Fastest; some embedded details and artwork may be unavailable.' },
  standard: { label: 'Standard', description: 'Recommended; reads normal tags and artwork without expensive duration traversal.' },
  deep: { label: 'Deep', description: 'Most thorough; reads extended tags and technical details.' },
});
export function normalizeMetadataScanQuality(value) { return value in SCAN_RANK ? value : 'standard'; }
function hasMetadataValue(value) { return Array.isArray(value) ? value.length > 0 : value !== '' && value != null; }
function mergeMetadata(base = {}, richer = {}) { const merged = { ...base }; for (const [key, value] of Object.entries(richer)) if (hasMetadataValue(value)) merged[key] = value; return merged; }
function unpackMetadataCache(record) {
  if (record && record.metadata && typeof record.metadata === 'object') return { quality: normalizeMetadataScanQuality(record.scanQuality), metadata: record.metadata };
  return record && typeof record === 'object' ? { quality: 'standard', metadata: record } : null;
}

function firstValue(value) {
  if (Array.isArray(value)) return firstValue(value[0]);
  if (value && typeof value === 'object' && 'data' in value) return firstValue(value.data);
  return value == null ? '' : value;
}
function textValue(value) {
  const resolved = firstValue(value);
  return resolved == null ? '' : String(resolved).trim();
}
function numberPart(value) {
  if (Number.isFinite(value)) return Number(value);
  if (value && typeof value === 'object') value = value.no ?? value.value ?? value.data;
  const match = String(value ?? '').match(/\d+/);
  return match ? Number(match[0]) || null : null;
}
function yearPart(value) {
  const match = textValue(value).match(/(?:19|20)\d{2}/);
  return match?.[0] || '';
}
function normalizePicture(picture) {
  const source = Array.isArray(picture) ? picture[0] : picture;
  if (!source?.data) return null;
  const data = source.data instanceof Uint8Array ? source.data : new Uint8Array(source.data);
  return { data, format: source.format || source.type || 'image/jpeg', description: source.description || '' };
}
function normalizeModernMetadata(result = {}) {
  const common = result.common || {};
  const format = result.format || {};
  return {
    title: textValue(common.title),
    artist: textValue(common.artist || common.artists),
    artists: (Array.isArray(common.artists) ? common.artists : [common.artist]).map(textValue).filter(Boolean),
    album: textValue(common.album),
    albumArtist: textValue(common.albumartist || common.albumArtist),
    genre: (Array.isArray(common.genre) ? common.genre : [common.genre]).map(textValue).filter(Boolean).join(', '),
    year: yearPart(common.year || common.date || common.originaldate),
    trackNumber: numberPart(common.track),
    trackTotal: numberPart(common.track?.of),
    discNumber: numberPart(common.disk || common.disc),
    discTotal: numberPart((common.disk || common.disc)?.of),
    composer: (Array.isArray(common.composer) ? common.composer : [common.composer]).map(textValue).filter(Boolean).join(', '),
    picture: normalizePicture(common.picture),
    duration: Number.isFinite(format.duration) ? format.duration : null,
    bitrate: Number.isFinite(format.bitrate) ? format.bitrate : null,
    sampleRate: Number.isFinite(format.sampleRate) ? format.sampleRate : null,
    numberOfChannels: Number.isFinite(format.numberOfChannels) ? format.numberOfChannels : null,
    codec: textValue(format.codec),
    container: textValue(format.container),
    metadataSource: 'music-metadata',
  };
}
function tagValue(tags, ...keys) {
  for (const key of keys) {
    const value = tags?.[key];
    if (value == null) continue;
    const resolved = firstValue(value);
    if (textValue(resolved)) return resolved;
  }
  return '';
}
function readLegacyAudioTags(file) {
  return new Promise(resolve => {
    if (!window.jsmediatags) return resolve({});
    window.jsmediatags.read(file, {
      onSuccess: ({ tags = {} }) => resolve({
        title: textValue(tagValue(tags, 'title', 'TIT2')),
        artist: textValue(tagValue(tags, 'artist', 'TPE1')),
        album: textValue(tagValue(tags, 'album', 'TALB')),
        albumArtist: textValue(tagValue(tags, 'albumartist', 'albumArtist', 'TPE2')),
        genre: textValue(tagValue(tags, 'genre', 'TCON')),
        year: yearPart(tagValue(tags, 'year', 'date', 'TYER', 'TDRC')),
        trackNumber: numberPart(tags.track || tags.TRCK),
        discNumber: numberPart(tags.disk || tags.disc || tags.TPOS),
        composer: textValue(tagValue(tags, 'composer', 'TCOM')),
        picture: normalizePicture(tags.picture || tags.APIC?.data),
        metadataSource: 'jsmediatags-fallback',
      }),
      onError: () => resolve({}),
    });
  });
}
async function parseAudioTags(file, quality = 'standard') {
  quality = normalizeMetadataScanQuality(quality);
  if (quality === 'quick') return { metadataSource: 'filename-and-folders' };
  try {
    const deep = quality === 'deep';
    return normalizeModernMetadata(await parseBlob(file, { duration: deep, skipCovers: false, skipPostHeaders: !deep }));
  } catch (error) {
    console.warn(`music-metadata could not parse ${file?.name || 'audio file'}; using compatibility parser.`, error);
    return readLegacyAudioTags(file);
  }
}
export async function readAudioTags(file, quality = state.settings.metadataScanQuality) { return parseAudioTags(file, quality); }
export function pictureUrl(picture) {
  const normalized = normalizePicture(picture);
  if (!normalized) return null;
  return URL.createObjectURL(new Blob([normalized.data], { type: normalized.format }));
}

function titleFromFilename(fileName) {
  return basename(fileName).replace(/[._]+/g, ' ').replace(/\s+/g, ' ').trim();
}

export function parseEpisodeIdentity(fileName,relativePath=''){
 const raw=titleFromFilename(fileName),parts=String(relativePath).replace(/\\/g,'/').split('/').filter(Boolean),folders=parts.slice(0,-1);let season=null,episode=null,match=null,collection='Videos';
 const explicit=/^(?:season|series|s)[ ._-]?(\d{1,3})$/i,compact=/^(.+?)[ ._-]*s(\d{1,3})$/i;
 for(let i=folders.length-1;i>=0;i--){let m=folders[i].match(explicit);if(m){season=Number(m[1]);collection=folders[i-1]||folders[Math.max(0,i-1)]||'Videos';break;}m=folders[i].match(compact);if(m){season=Number(m[2]);collection=m[1].replace(/[ ._-]+$/,'').trim()||folders[i-1]||'Videos';break;}}
 const patterns=[/S(\d{1,3})E(\d{1,4})/i,/(\d{1,3})x(\d{1,4})/i,/(?:episode|ep)[ ._-]?(\d{1,4})/i,/([A-Za-z][A-Za-z0-9 _-]*?)Ep(\d{1,4})/i,/^(\d{1,4})[ ._-]+/];
 for(let i=0;i<patterns.length;i++){match=raw.match(patterns[i]);if(!match)continue;if(i<2){season=season??Number(match[1]);episode=Number(match[2]);}else if(i===3){episode=Number(match[2]);if(collection==='Videos')collection=match[1].replace(/[ _-]+$/,'').trim()||collection;}else episode=Number(match[1]);break;}
 if(collection==='Videos'){const last=folders.at(-1)||'';const cm=last.match(compact);if(cm){collection=cm[1].trim();season=season??Number(cm[2]);}else if(folders.length>1)collection=folders.at(-2);else if(last)collection=last;}
 if(episode!=null&&season==null)season=1;let title=match?raw.replace(match[0],' ').replace(/[-–—]+/g,' ').replace(/\s+/g,' ').trim():raw;if(!title&&episode!=null)title=`Episode ${episode}`;if(title===collection&&episode!=null)title=`Episode ${episode}`;return{title:title||raw,collection,season,episode,folderParts:folders};
}
export async function createMedia(file, relativePath, mediaType, options = {}) {
  const quality = normalizeMetadataScanQuality(options.scanQuality || state.settings.metadataScanQuality);
  const key = `file:${normalizePath(relativePath)}`;
  const cacheKey = `${METADATA_CACHE_VERSION}|${key}|${file.size}|${file.lastModified}`;
  const cached = unpackMetadataCache(await readMetadataCache(cacheKey));
  let metadata;
  let effectiveQuality = quality;
  if (!options.force && cached && SCAN_RANK[cached.quality] >= SCAN_RANK[quality]) {
    metadata = cached.metadata; effectiveQuality = cached.quality;
  } else {
    const scanned = mediaType === 'audio' ? await parseAudioTags(file, quality) : parseEpisodeIdentity(file.name, relativePath);
    if (cached && SCAN_RANK[cached.quality] > SCAN_RANK[quality]) { metadata = cached.metadata; effectiveQuality = cached.quality; }
    else { metadata = mergeMetadata(cached?.metadata, scanned); effectiveQuality = quality; }
    await writeMetadataCache(cacheKey, { scanQuality: effectiveQuality, parserSchema: METADATA_CACHE_VERSION, metadata });
  }
  const common = { key, type: mediaType, source: 'file', file, relativePath, fileName: file.name,
    extension: extension(file.name), size: file.size, modified: file.lastModified,
    duration: Number.isFinite(metadata.duration) ? metadata.duration : null, metadataScanQuality: effectiveQuality };
  if (mediaType === 'video') return { ...common, title: metadata.title || titleFromFilename(file.name), artist: metadata.collection || 'Local Video',
    album: metadata.collection || 'Videos', albumArtist: metadata.collection || 'Local Video', genre: 'Video', year: '', trackNo: metadata.episode || '', coverUrl: null,
    collection: metadata.collection || 'Videos', season: metadata.season || null, episode: metadata.episode || null, folderParts: metadata.folderParts || [] };
  return { ...common, title: metadata.title || titleFromFilename(file.name), artist: metadata.artist || 'Unknown Artist', artists: metadata.artists || [],
    album: metadata.album || 'Unknown Album', albumArtist: metadata.albumArtist || metadata.artist || 'Unknown Artist', genre: metadata.genre || 'Unknown Genre', year: metadata.year || '',
    trackNo: metadata.trackNumber || '', trackTotal: metadata.trackTotal || '', discNo: metadata.discNumber || '', discTotal: metadata.discTotal || '',
    composer: metadata.composer || '', coverUrl: pictureUrl(metadata.picture), bitrate: metadata.bitrate || null, sampleRate: metadata.sampleRate || null,
    numberOfChannels: metadata.numberOfChannels || null, codec: metadata.codec || '', container: metadata.container || '', metadataSource: metadata.metadataSource || '',
    collection: null, season: null, episode: null };
}
export async function rescanMediaItems(items, quality = state.settings.metadataScanQuality, onProgress) {
  quality = normalizeMetadataScanQuality(quality);
  const targets = (items || []).filter(item => item?.file && item?.relativePath && (item.type === 'audio' || item.type === 'video'));
  for (let index = 0; index < targets.length; index += 1) {
    const item = targets[index];
    const refreshed = await createMedia(item.file, item.relativePath, item.type, { scanQuality: quality, force: true });
    if (item.coverUrl && item.coverUrl !== refreshed.coverUrl && item.coverUrl.startsWith('blob:')) URL.revokeObjectURL(item.coverUrl);
    Object.assign(item, refreshed); onProgress?.({ done: index + 1, total: targets.length, item });
  }
  return { rescanned: targets.length, total: targets.length, quality };
}

function showStartupError(error){
  console.error('NaviPlayer failed to start.',error);
  let banner=document.getElementById('startupError');
  if(!banner){banner=document.createElement('div');banner.id='startupError';banner.className='startup-error';document.body.prepend(banner);}
  banner.replaceChildren();
  const message=document.createElement('span');message.textContent=`NaviPlayer failed to start: ${error?.message||error}`;
  const details=document.createElement('details'),summary=document.createElement('summary'),pre=document.createElement('pre');summary.textContent='Details';pre.textContent=error?.stack||String(error);details.append(summary,pre);
  const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Dismiss error');close.onclick=()=>banner.remove();banner.append(message,details,close);
}
window.addEventListener('unhandledrejection',event=>console.error('Unhandled NaviPlayer rejection',event.reason));
import('./ui.js').then(module=>module.initializeUI()).catch(showStartupError);

import { loadSetting, saveSetting, removeSetting, readPersistenceSnapshot, writePersistenceSnapshot, readUserData, writeUserData, migrateLocalToIndexedDB } from './storage.js';

export function emptyIndexes() {
  return {
    path: new Map(),
    pathNoExtension: new Map(),
    file: new Map(),
    base: new Map(),
    metadata: new Map(),
  };
}

export const state = {
  library: [],
  byKey: new Map(),
  indexes: emptyIndexes(),
  collections: { albums: [], artists: [], genres: [], shows: [] },
  playlists: loadSetting('playlists', []),
  likedMedia: new Set(loadSetting('likedMedia', [])),
  likedEntities: new Set(loadSetting('likedEntities', [])),
  watchState: loadSetting('watchState', {}),
  metadataOverrides: loadSetting('metadataOverrides', {}),
  baseMetadata: loadSetting('baseMetadata', {}),
  captionLyrics: loadSetting('captionLyrics', { captions: {}, lyrics: {} }),
  playbackIssues: loadSetting('playbackIssues', []),
  side: 'all',
  browseHistory: [],
  browseHistoryIndex: -1,
  selectedSeason: null,
  collectionBrowse: false,
  libraryLayout: (()=>{const saved=loadSetting('libraryLayout',{});const legacy=loadSetting('collectionViewMode','standard');return{mode:saved.mode||(['icons','cards'].includes(legacy)?'icons':'rows'),icons:{columns:Math.min(8,Math.max(1,Number(saved.icons?.columns)||4)),titleLines:Number(saved.icons?.titleLines)||2,metadata:saved.icons?.metadata||'detailed',actions:saved.icons?.actions||'always'},rows:{columns:Math.min(8,Math.max(1,Number(saved.rows?.columns)||1)),height:saved.rows?.height||'standard',artwork:saved.rows?.artwork||'medium',metadataLines:Number(saved.rows?.metadataLines)||2,actions:saved.rows?.actions||'always'}};})(),
  collectionViewMode: 'rows',
  entityViewMode: 'standard',
  mediaViewMode: 'standard',
  metadataSubtab: 'details',
  listeningHistory: loadSetting('listeningHistory',[]),
  view: 'tracks',
  selected: null,
  lastImport: [],
  queue: [],
  queueIndex: -1,
  search:'',
  searchDocuments:[],
  searchVersion:0,
  mediaFilter: 'all',
  libraryFilter: 'all',
  sortMode: 'default',
  pinnedCollections: new Set(loadSetting('pinnedCollections', [])),
  contextTab: 'queue',
  opened: null,
  inspected: null,
  selection: { active: false, keys: new Set() },
  sleepTimer: { mode: 'off', deadline: 0, fade: false },
  fileAccess: { supported: false, status: 'unavailable', folderName: '', message: '' },
  objectUrl: null,
  hls: null,
  renderedRows: [],
  contextItem: null,
  settings: {
    shuffle: false,
    shuffleMode: 'smart',
    transitionFadeMs: 1200,
    autoplayQueued: false,
    metadataScanQuality: 'standard',
    repeat: 'all',
    volume: 1,
    volumeBoost: 1,
    volumeLeveling: 'off',
    dark: false,
    compact: false,
    colorMode: 'system',
    density: 'comfortable',
    compactRows: false,
    tvMode: false,
    themePreset: 'purple',
    customAccent: '#8b5cf6',
    aesthetic: 'default',
    wallpaper: '',
    wallpaperBlur: 8,
    wallpaperBrightness: 75,
    wallpaperTint: 30,
    showBranding: true,
    panelOpacity: 96,
    libraryOpacity: 96,
    contextOpacity: 96,
    navigationOpacity: 96,
    menuOpacity: 98,
    windowOpacity: 98,
    cardOpacity: 96,
    rowOpacity: 96,
    queueOpacity: 96,
    statusOpacity: 98,
    footerOpacity: 98,
    controlOpacity: 100,
    dockOpacity: 96,
    rightWidth: 400,
    workspaceLayout: 'automatic',
    resolvedWorkspaceLayout: 'desktop',
    compactContextWidth: 340,
    compactFooter: true,
    browseContextCollapsed: false,
    browseContextWidth: 300,
    playbackLibraryOpen: false,
    playbackContextCollapsed: false,
    queueFollowCurrent: true,
    workspaceRailAutohide: false,
    footerVolumeHover: true,
    audioBalance: 0,
    eqPreset: 'flat',
    eqBands: [0,0,0,0,0,0,0,0,0,0],
    smartQueueProfile: {artistGap:3,albumGap:2,recentGap:20,preferLiked:false,preferUnplayed:false,sequentialEpisodes:true},
    resumeLastSession: true,
    playbackContextWidth: 380,
    playbackAutoActivateVideo: false,
    mobilePage: 'library',
    mobileDefaultPage: 'library',
    mobileMiniPlayer: true,
    mobileAutoOpenVideo: true,
    toolWindowX: 80,
    toolWindowY: 80,
    toolWindows: {},
    alwaysCenterToolWindows: true,
    rememberToolWindowPositions: false,
    remember: true,
    exportExtension: 'm3u8',
    ...loadSetting('settings', {}),
  },
};

const PERSISTENCE_SCHEMA=3;const HEAVY_KEYS=['metadataOverrides','baseMetadata','captionLyrics','listeningHistory'];let snapshotTimer=0;
const objectSize=value=>Array.isArray(value)?value.length:value&&typeof value==='object'?Object.keys(value).length:0;
function compactSettings(){const settings={...state.settings};delete settings.wallpaper;return settings;}function persistencePayload(){return{schema:PERSISTENCE_SCHEMA,updatedAt:Date.now(),settings:compactSettings(),libraryLayout:state.libraryLayout,playlists:state.playlists,likedMedia:[...state.likedMedia],likedEntities:[...state.likedEntities],watchState:state.watchState,metadataOverrides:state.metadataOverrides,baseMetadata:state.baseMetadata,captionLyrics:state.captionLyrics,playbackIssues:state.playbackIssues,pinnedCollections:[...state.pinnedCollections],listeningHistory:state.listeningHistory};}
export function schedulePersistenceSnapshot(){clearTimeout(snapshotTimer);snapshotTimer=setTimeout(()=>writePersistenceSnapshot('user-state',persistencePayload()).catch(error=>console.warn('Unable to mirror NaviPlayer state.',error)),120);}
export async function restorePersistenceSnapshot(){const snapshot=await readPersistenceSnapshot('user-state');if(!snapshot||snapshot.schema<1)return{restored:false};const restoreArray=(current,saved)=>Array.isArray(saved)&&saved.length>current.length?saved:current,restoreObject=(current,saved)=>saved&&typeof saved==='object'&&objectSize(saved)>objectSize(current)?saved:current;
 state.playlists=restoreArray(state.playlists,snapshot.playlists);state.likedMedia=new Set(restoreArray([...state.likedMedia],snapshot.likedMedia));state.likedEntities=new Set(restoreArray([...state.likedEntities],snapshot.likedEntities));state.watchState=restoreObject(state.watchState,snapshot.watchState);state.metadataOverrides=restoreObject(state.metadataOverrides,snapshot.metadataOverrides);state.baseMetadata=restoreObject(state.baseMetadata,snapshot.baseMetadata);state.captionLyrics={captions:restoreObject(state.captionLyrics?.captions,snapshot.captionLyrics?.captions),lyrics:restoreObject(state.captionLyrics?.lyrics,snapshot.captionLyrics?.lyrics)};state.playbackIssues=restoreArray(state.playbackIssues,snapshot.playbackIssues);state.pinnedCollections=new Set(restoreArray([...state.pinnedCollections],snapshot.pinnedCollections));state.listeningHistory=restoreArray(state.listeningHistory,snapshot.listeningHistory);if(snapshot.settings&&typeof snapshot.settings==='object')state.settings={...state.settings,...snapshot.settings};if(snapshot.libraryLayout&&typeof snapshot.libraryLayout==='object')state.libraryLayout={...state.libraryLayout,...snapshot.libraryLayout,icons:{...state.libraryLayout.icons,...snapshot.libraryLayout.icons},rows:{...state.libraryLayout.rows,...snapshot.libraryLayout.rows}};return{restored:true,updatedAt:snapshot.updatedAt||0};}
export async function restoreHeavyUserData(){const [metadataOverrides,baseMetadata,captionLyrics,listeningHistory]=await Promise.all(HEAVY_KEYS.map(readUserData));if(metadataOverrides)state.metadataOverrides=metadataOverrides;if(baseMetadata)state.baseMetadata=baseMetadata;if(captionLyrics)state.captionLyrics=captionLyrics;if(listeningHistory)state.listeningHistory=listeningHistory;const wallpaper=await readUserData('wallpaper');if(wallpaper)state.settings.wallpaper=wallpaper;return{metadataOverrides:Boolean(metadataOverrides),baseMetadata:Boolean(baseMetadata),captionLyrics:Boolean(captionLyrics),listeningHistory:Boolean(listeningHistory),wallpaper:Boolean(wallpaper)};}
export async function migrateHeavyLocalData(){const results=[];for(const key of HEAVY_KEYS)results.push(await migrateLocalToIndexedDB(key,{prune:true}));if(state.settings.wallpaper){await writeUserData('wallpaper',state.settings.wallpaper);const settings={...state.settings};delete settings.wallpaper;state.settings=settings;saveSetting('settings',settings);}return results;}
export async function saveWallpaperData(value){if(value)await writeUserData('wallpaper',value);else await writeUserData('wallpaper','');state.settings.wallpaper=value||'';saveSettings();schedulePersistenceSnapshot();}
export function saveSettings(){if(state.settings.remember){saveSetting('settings',compactSettings());schedulePersistenceSnapshot();}}
export function savePlaylists(){saveSetting('playlists',state.playlists);schedulePersistenceSnapshot();}
export function saveLikedMedia(){saveSetting('likedMedia',[...state.likedMedia]);schedulePersistenceSnapshot();}
export function saveLikedEntities(){saveSetting('likedEntities',[...state.likedEntities]);schedulePersistenceSnapshot();}
export function saveWatchState(){saveSetting('watchState',state.watchState);schedulePersistenceSnapshot();}
const normalizedPath=value=>String(value||'').replace(/\\/g,'/').replace(/^\.\//,'').replace(/\/+/g,'/').trim().toLowerCase();
export const stableMediaKey=value=>{if(value&&typeof value==='object'&&value.relativePath)return`file:${normalizedPath(value.relativePath)}`;const raw=String(typeof value==='string'?value:value?.key||'');return raw.replace(/(file:[^|]+)\|\d+\|\d+$/,'$1').toLowerCase();};
export function migrateStableMediaKeys(){const original={liked:state.likedMedia.size,watch:objectSize(state.watchState),metadata:objectSize(state.metadataOverrides),base:objectSize(state.baseMetadata),captions:objectSize(state.captionLyrics?.captions),lyrics:objectSize(state.captionLyrics?.lyrics)};state.likedMedia=new Set([...state.likedMedia].map(stableMediaKey).filter(Boolean));const migrateObject=source=>Object.fromEntries(Object.entries(source||{}).map(([key,value])=>[stableMediaKey(key),value]).filter(([key])=>key));state.watchState=migrateObject(state.watchState);state.metadataOverrides=migrateObject(state.metadataOverrides);state.baseMetadata=migrateObject(state.baseMetadata);state.captionLyrics={captions:migrateObject(state.captionLyrics?.captions),lyrics:migrateObject(state.captionLyrics?.lyrics)};for(const playlist of state.playlists||[])playlist.trackKeys=[...new Set((playlist.trackKeys||[]).map(stableMediaKey).filter(Boolean))];if(state.settings.density==='compact')state.settings.density='comfortable';state.settings.compactRows=false;const legacy=state.collectionViewMode;state.libraryLayout.mode=['icons','cards'].includes(legacy)?'icons':(state.libraryLayout.mode||'rows');state.collectionViewMode=state.entityViewMode=state.mediaViewMode=state.libraryLayout.mode;if(original.liked)saveLikedMedia();if(original.watch)saveWatchState();if(original.metadata||original.base)saveMetadataOverrides();if(original.captions||original.lyrics)saveCaptionLyrics();if(state.playlists.length)savePlaylists();saveSettings();}
export function saveMetadataOverrides(){writeUserData('metadataOverrides',state.metadataOverrides);writeUserData('baseMetadata',state.baseMetadata);removeSetting('metadataOverrides');removeSetting('baseMetadata');schedulePersistenceSnapshot();}
export function saveCaptionLyrics(){writeUserData('captionLyrics',state.captionLyrics);removeSetting('captionLyrics');schedulePersistenceSnapshot();}
export function savePlaybackIssues(){saveSetting('playbackIssues',state.playbackIssues);schedulePersistenceSnapshot();}
export function savePinnedCollections(){saveSetting('pinnedCollections',[...state.pinnedCollections]);schedulePersistenceSnapshot();}
export function saveCollectionViewMode(){saveSetting('collectionViewMode',state.libraryLayout.mode);saveSetting('libraryLayout',state.libraryLayout);schedulePersistenceSnapshot();}
export function saveListeningHistory(){state.listeningHistory=state.listeningHistory.slice(-5000);writeUserData('listeningHistory',state.listeningHistory);removeSetting('listeningHistory');schedulePersistenceSnapshot();}


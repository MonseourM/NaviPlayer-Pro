import { state, savePlaybackIssues } from './state.js';
const LIMIT=100;
export function recordPlaybackIssue({item,message,reason='',code=''}){state.playbackIssues.unshift({id:globalThis.crypto?.randomUUID?.()||String(Date.now()),timestamp:Date.now(),title:item?.title||'Unknown media',path:item?.relativePath||item?.url||'',type:item?.type||'',source:item?.source||'',message:message||'Playback failed.',reason,code});state.playbackIssues=state.playbackIssues.slice(0,LIMIT);savePlaybackIssues();}
export function clearPlaybackIssues(){state.playbackIssues=[];savePlaybackIssues();}
export function issueSummary(){return state.playbackIssues;}

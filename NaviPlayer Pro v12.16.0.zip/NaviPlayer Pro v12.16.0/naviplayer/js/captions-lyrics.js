import { state, saveCaptionLyrics, stableMediaKey } from './state.js';
let activeCaptionUrl=null;
let activeCaptionKey=null;
function srtToVtt(text){return 'WEBVTT\n\n'+String(text).replace(/^\s*WEBVTT\s*/i,'').replace(/(\d{2}:\d{2}:\d{2}),([0-9]{3})/g,'$1.$2');}
export async function attachCaptionFile(item,file,video){if(!item?.key||item.type!=='video'||!file)return{status:'invalid',message:'Select a video before loading captions.'};let text=await file.text();if(/\.srt$/i.test(file.name))text=srtToVtt(text);if(activeCaptionUrl)URL.revokeObjectURL(activeCaptionUrl);activeCaptionUrl=URL.createObjectURL(new Blob([text],{type:'text/vtt'}));for(const track of [...video.querySelectorAll('track[data-naviplayer-caption]')])track.remove();const track=document.createElement('track');track.kind='subtitles';track.label=file.name;track.srclang='en';track.default=true;track.dataset.naviplayerCaption='1';track.src=activeCaptionUrl;video.append(track);activeCaptionKey=stableMediaKey(item);state.captionLyrics.captions[stableMediaKey(item)]={name:file.name,text};saveCaptionLyrics();return{status:'loaded',message:`Loaded captions: ${file.name}`};}
export function restoreCaptions(item,video){if(stableMediaKey(item)===activeCaptionKey&&video.querySelector('track[data-naviplayer-caption]'))return true;const key=stableMediaKey(item),entry=key&&state.captionLyrics.captions[key];if(!entry||item?.type!=='video')return false;const file=new File([entry.text],entry.name,{type:'text/vtt'});attachCaptionFile(item,file,video);return true;}
export function toggleCaptions(video){const tracks=[...video.textTracks];if(!tracks.length)return false;const showing=tracks.some(track=>track.mode==='showing');tracks.forEach(track=>track.mode=showing?'disabled':'showing');return !showing;}
export async function loadLyricsFile(item,file){if(!item?.key||!file)return{status:'invalid',message:'Select media before loading lyrics.'};const text=await file.text();const parsed=parseLrc(text);state.captionLyrics.lyrics[stableMediaKey(item)]={name:file.name,text:parsed.length?parsed.map(line=>line.text).join('\n'):text,synced:Boolean(parsed.length),raw:text};saveCaptionLyrics();return{status:'loaded',message:`Loaded lyrics: ${file.name}`};}
export function lyricsFor(item){return item?.key?state.captionLyrics.lyrics[stableMediaKey(item)]||null:null;}
export function lyricLinesFor(item){const entry=lyricsFor(item);if(!entry)return[];if(entry.synced&&entry.raw)return parseLrc(entry.raw);return String(entry.text||'').split(/\r?\n/).filter(Boolean).map(text=>({t:null,text}));}
export function cleanupCaptionUrl(){if(activeCaptionUrl)URL.revokeObjectURL(activeCaptionUrl);activeCaptionUrl=null;activeCaptionKey=null;}

function parseLrc(text){
  const lines=[];
  for(const raw of String(text||'').split(/\r?\n/)){
    const stamps=[...raw.matchAll(/\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
    const value=raw.replace(/\[[^\]]+\]/g,'').trim();
    for(const stamp of stamps){const fraction=Number(`0.${String(stamp[3]||'0').padEnd(3,'0').slice(0,3)}`);lines.push({t:Number(stamp[1])*60+Number(stamp[2])+fraction,text:value});}
  }
  return lines.sort((a,b)=>a.t-b.t);
}
function lyricsText(record){
  if(record.syncedLyrics){const parsed=parseLrc(record.syncedLyrics);if(parsed.length)return parsed.map(line=>line.text).join('\n');}
  return record.plainLyrics||record.syncedLyrics||'';
}
async function lrclibRecord(item){
  if(!item||item.type!=='audio')throw new Error('Lyrics are available for audio only.');
  const title=!/^unknown/i.test(item.title||'')?item.title:'';
  const artist=!/^unknown/i.test(item.artist||'')?item.artist:'';
  const album=!/^unknown/i.test(item.album||'')?item.album:'';
  const duration=Math.round(Number(item.duration||0));
  if(!title)throw new Error('A track title is required to fetch lyrics.');
  const query=values=>new URLSearchParams(Object.entries(values).filter(([,value])=>value!==''&&value!=null)).toString();
  const urls=[];
  if(artist&&duration)urls.push(`https://lrclib.net/api/get?${query({artist_name:artist,track_name:title,album_name:album,duration})}`);
  urls.push(`https://lrclib.net/api/search?${query({track_name:title,artist_name:artist})}`);
  for(const url of urls){try{const response=await fetch(url,{headers:{'Lrclib-Client':'NaviPlayer Pro'}});if(!response.ok)continue;const data=await response.json();const record=Array.isArray(data)?data.find(value=>value.syncedLyrics)||data[0]:data;if(record&&(record.syncedLyrics||record.plainLyrics))return record;}catch{}}
  return null;
}
export async function fetchLyricsForItem(item){
  const record=await lrclibRecord(item);if(!record)return{status:'missing',message:'No lyrics found on LRCLIB.'};
  state.captionLyrics.lyrics[stableMediaKey(item)]={name:'LRCLIB',text:lyricsText(record),synced:Boolean(record.syncedLyrics),raw:record.syncedLyrics||record.plainLyrics||''};saveCaptionLyrics();
  return{status:'loaded',message:record.syncedLyrics?'Synced lyrics loaded from LRCLIB.':'Unsynced lyrics loaded from LRCLIB.'};
}
export async function fetchAllMissingLyrics(onProgress=()=>{}){
  const items=state.library.filter(item=>item.type==='audio'&&!state.captionLyrics.lyrics[stableMediaKey(item)]);let found=0;
  for(let index=0;index<items.length;index++){try{const result=await fetchLyricsForItem(items[index]);if(result.status==='loaded')found++;}catch{}onProgress(index+1,items.length,found);await new Promise(resolve=>setTimeout(resolve,350));}
  return{found,total:items.length};
}

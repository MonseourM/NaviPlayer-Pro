import { state, savePlaylists } from './state.js';
import { readHandle, writeHandle, deleteHandle } from './storage.js';

const keyFor = id => `playlist-file:${id}`;
const timers = new Map();
export const supportsEditablePlaylists = () => typeof window.showOpenFilePicker === 'function';
async function permission(handle, request = false) {
  if (!handle) return 'denied';
  const descriptor = { mode: 'readwrite' };
  try {
    const existing = await handle.queryPermission(descriptor);
    if (existing === 'granted' || !request) return existing;
    return await handle.requestPermission(descriptor);
  } catch { return 'denied'; }
}
export async function openEditablePlaylist() {
  if (!supportsEditablePlaylists()) return { status: 'unsupported', message: 'Editable playlist files are unavailable in this browser or embedded workspace.' };
  try {
    const [handle] = await window.showOpenFilePicker({ multiple: false, types: [{ description: 'M3U playlists', accept: { 'audio/x-mpegurl': ['.m3u', '.m3u8'] } }] });
    const file = await handle.getFile();
    const { importPlaylistFile } = await import('./playlists.js');
    const result = await importPlaylistFile(file);
    result.playlist.linkedFile = { name: file.name, status: 'connected' };
    await writeHandle(keyFor(result.playlist.id), handle);
    savePlaylists();
    return { status: 'connected', ...result };
  } catch (error) {
    return { status: error?.name === 'AbortError' ? 'cancelled' : 'error', message: error?.message || 'Unable to open editable playlist.' };
  }
}
export async function linkedPlaylistStatus(playlist) {
  if (!playlist?.linkedFile) return { status: 'unlinked' };
  const handle = await readHandle(keyFor(playlist.id));
  if (!handle) return { status: 'missing', name: playlist.linkedFile.name };
  return { status: await permission(handle, false), name: handle.name };
}
export async function saveLinkedPlaylist(playlist, request = false) {
  if (!playlist?.linkedFile) return { status: 'unlinked', message: 'This playlist is not linked to a file.' };
  const handle = await readHandle(keyFor(playlist.id));
  if (!handle) return { status: 'missing', message: 'The saved playlist handle is unavailable.' };
  const access = await permission(handle, request);
  if (access !== 'granted') return { status: 'reconnect', message: `Reconnect ${handle.name} before saving.` };
  try {
    const writable = await handle.createWritable();
    const { serializePlaylist } = await import('./playlists.js');
    await writable.write(serializePlaylist(playlist));
    await writable.close();
    playlist.linkedFile = { name: handle.name, status: 'connected', savedAt: Date.now() };
    savePlaylists();
    return { status: 'saved', message: `Saved ${handle.name}.` };
  } catch (error) {
    return { status: 'error', message: error?.message || 'Playlist write failed.' };
  }
}
export function scheduleLinkedPlaylistSave(playlist) {
  if (!playlist?.linkedFile) return;
  clearTimeout(timers.get(playlist.id));
  timers.set(playlist.id, setTimeout(() => saveLinkedPlaylist(playlist, false), 500));
}
export async function reconnectLinkedPlaylist(playlist) { return saveLinkedPlaylist(playlist, true); }
export async function unlinkPlaylistFile(playlist) {
  if (!playlist) return;
  await deleteHandle(keyFor(playlist.id));
  delete playlist.linkedFile;
  savePlaylists();
}

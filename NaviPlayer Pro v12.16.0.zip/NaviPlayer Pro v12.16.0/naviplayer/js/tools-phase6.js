import { state, savePlaylists, saveSettings, saveLikedMedia, saveLikedEntities, saveWatchState, saveMetadataOverrides, saveCaptionLyrics, savePlaybackIssues, savePinnedCollections, saveListeningHistory, saveCollectionViewMode, stableMediaKey, schedulePersistenceSnapshot, migrateStableMediaKeys, saveWallpaperData } from './state.js';
import { clearMetadataCache, clearThumbnailCache, clearParsedMetadataCache, storageDiagnostics } from './storage.js';
import { createPlaylist, addTrackWithoutSaving } from './playlists.js';
import { audio, video, activeElement, stopPlayback } from './playback.js';
import { rescanMediaItems, normalizeMetadataScanQuality } from './metadata.js';

let sleepInterval=null;
let endListener=null;
const download=(name,text,type='application/json')=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
export function exportBackup(){
  const payload={schema:'NaviPlayer-v12-backup',version:2,createdAt:new Date().toISOString(),settings:state.settings,libraryLayout:state.libraryLayout,playlists:state.playlists,likedMedia:[...state.likedMedia],likedEntities:[...state.likedEntities],watchState:state.watchState,metadataOverrides:state.metadataOverrides,baseMetadata:state.baseMetadata,captionLyrics:state.captionLyrics,playbackIssues:state.playbackIssues,pinnedCollections:[...state.pinnedCollections],listeningHistory:state.listeningHistory};
  download('NaviPlayer-v12-backup.json',JSON.stringify(payload,null,2));
}
export async function importBackup(file){
  const data=JSON.parse(await file.text());
  if(data?.schema!=='NaviPlayer-v12-backup'||![1,2].includes(data.version))throw new Error('This is not a supported NaviPlayer v12 backup.');
  if(data.settings)Object.assign(state.settings,data.settings);if(data.libraryLayout)state.libraryLayout={...state.libraryLayout,...data.libraryLayout,icons:{...state.libraryLayout.icons,...data.libraryLayout.icons},rows:{...state.libraryLayout.rows,...data.libraryLayout.rows}};
  if(Array.isArray(data.playlists))state.playlists=data.playlists;
  state.likedMedia=new Set(Array.isArray(data.likedMedia)?data.likedMedia.map(stableMediaKey).filter(Boolean):[]);state.likedEntities=new Set(Array.isArray(data.likedEntities)?data.likedEntities:[]);
  state.watchState=data.watchState&&typeof data.watchState==='object'?data.watchState:{};
  state.metadataOverrides=data.metadataOverrides&&typeof data.metadataOverrides==='object'?data.metadataOverrides:{};
  state.baseMetadata=data.baseMetadata&&typeof data.baseMetadata==='object'?data.baseMetadata:{};
  state.captionLyrics=data.captionLyrics&&typeof data.captionLyrics==='object'?data.captionLyrics:{captions:{},lyrics:{}};
  state.playbackIssues=Array.isArray(data.playbackIssues)?data.playbackIssues:[];state.pinnedCollections=new Set(Array.isArray(data.pinnedCollections)?data.pinnedCollections:[]);state.listeningHistory=Array.isArray(data.listeningHistory)?data.listeningHistory:[];if(data.settings?.wallpaper)await saveWallpaperData(data.settings.wallpaper);migrateStableMediaKeys();
  saveSettings();saveCollectionViewMode();savePlaylists();saveLikedMedia();saveLikedEntities();saveWatchState();saveMetadataOverrides();saveCaptionLyrics();savePlaybackIssues();savePinnedCollections();saveListeningHistory();schedulePersistenceSnapshot();
}
export function exportWatchedList(){
  const rows=['Title,Path,Position,Duration,Watched,Updated'];
  for(const item of state.library.filter(x=>x.type==='video')){const w=state.watchState[stableMediaKey(item)];if(!w)continue;const q=v=>`"${String(v??'').replaceAll('"','""')}"`;rows.push([q(item.title),q(item.relativePath),Math.round(w.position||0),Math.round(w.duration||0),w.watched?'Yes':'No',w.updatedAt?new Date(w.updatedAt).toISOString():''].join(','));}
  download('NaviPlayer-watched-list.csv',rows.join('\n'),'text/csv');
}
export function clearCurrentProgress(item){if(item?.key){delete state.watchState[stableMediaKey(item)];saveWatchState();}}
export function clearWatchData(){state.watchState={};saveWatchState();}
export function clearLibraryData(){stopPlayback();for(const item of state.library){if(item.coverUrl?.startsWith('blob:'))URL.revokeObjectURL(item.coverUrl);}state.library=[];state.byKey.clear();state.queue=[];state.queueIndex=-1;state.selected=null;state.opened=null;state.inspected=null;}
export function duplicatePath(item){return item.relativePath||item.fileName||item.url||'(path unavailable)';}
export function findDuplicates(){const groups=new Map();for(const item of state.library){const key=`${String(item.artist||'').toLowerCase()}|${String(item.title||'').toLowerCase()}|${item.size||0}`;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);}return [...groups.values()].filter(group=>group.length>1);}
export function libraryStatistics(){return{total:state.library.length,audio:state.library.filter(x=>x.type==='audio').length,video:state.library.filter(x=>x.type==='video').length,liked:state.library.filter(x=>state.likedMedia.has(stableMediaKey(x))).length,playlists:state.playlists.length,watched:Object.values(state.watchState).filter(x=>x.watched).length,duplicates:findDuplicates().length};}
export async function autoTagUnknown(){let changed=0;for(const item of state.library.filter(x=>x.type==='audio')){if(item.artist==='Unknown Artist'&&item.relativePath){const parts=item.relativePath.replace(/\\/g,'/').split('/');const artist=parts.length>1?parts.at(-2):'';if(artist){const key=stableMediaKey(item);state.metadataOverrides[key]={...(state.metadataOverrides[key]||{}),artist};item.artist=artist;changed++;}}}if(changed){saveMetadataOverrides();const { applyAllOverrides }=await import('./metadata-overrides.js');await applyAllOverrides();}return changed;}
export function selectedItems(){return [...state.selection.keys].map(key=>state.byKey.get(key)).filter(Boolean);}
export function toggleSelection(item){if(!item?.key)return;if(state.selection.keys.has(item.key))state.selection.keys.delete(item.key);else state.selection.keys.add(item.key);}
export function exitSelection(){state.selection.active=false;state.selection.keys.clear();}
export function createPlaylistFromSelection(name){const items=selectedItems();const playlist=createPlaylist(name);for(const item of items)addTrackWithoutSaving(item,playlist);savePlaylists();return playlist;}
function clearTimer(){if(sleepInterval)clearInterval(sleepInterval);sleepInterval=null;if(endListener){audio.removeEventListener('ended',endListener);video.removeEventListener('ended',endListener);endListener=null;}state.sleepTimer={mode:'off',deadline:0,fade:false};}
export function cancelSleepTimer(){clearTimer();}
export function setSleepTimer(mode,fade=false,onTick=()=>{}){
  clearTimer();state.sleepTimer={mode,deadline:0,fade};
  const stop=()=>{const media=activeElement();if(fade){const start=media.volume,steps=20;let i=0;const fadeTimer=setInterval(()=>{i++;media.volume=Math.max(0,start*(1-i/steps));if(i>=steps){clearInterval(fadeTimer);media.pause();media.volume=state.settings.volume;clearTimer();onTick();}},250);}else{media.pause();clearTimer();onTick();}};
  if(['15','30','45','60'].includes(mode)){state.sleepTimer.deadline=Date.now()+Number(mode)*60000;sleepInterval=setInterval(()=>{onTick();if(Date.now()>=state.sleepTimer.deadline)stop();},1000);}
  else if(mode==='item'){endListener=stop;activeElement().addEventListener('ended',endListener,{once:true});}
  else if(mode==='queue'){sleepInterval=setInterval(()=>{onTick();if(state.queueIndex===state.queue.length-1&&activeElement().ended)stop();},1000);}
  return state.sleepTimer;
}
export function sleepStatus(){if(state.sleepTimer.mode==='off')return'Off';if(state.sleepTimer.deadline)return`${Math.max(0,Math.ceil((state.sleepTimer.deadline-Date.now())/60000))} min remaining`;return state.sleepTimer.mode==='item'?'End of current item':'End of Queue';}
export async function persistenceDiagnostics(options={}){return await storageDiagnostics(['settings','libraryLayout','playlists','likedMedia','likedEntities','watchState','metadataOverrides','baseMetadata','captionLyrics','playbackIssues','pinnedCollections','listeningHistory','wallpaper'],options);}
export async function clearCache(){await clearMetadataCache();}
export async function clearThumbnailData(){await clearThumbnailCache();}
export async function clearParsedMetadata(){await clearParsedMetadataCache();}

export function exportDuplicateReport(groups=findDuplicates()){const rows=['NaviPlayer Pro Duplicate Report',''];for(const [index,group] of groups.entries()){rows.push(`Group ${index+1}: ${group[0]?.artist||'Unknown'} — ${group[0]?.title||'Untitled'} (${group.length} files)`);for(const item of group)rows.push(`  ${duplicatePath(item)} | ${item.extension||''} | ${item.size||0} bytes | ${item.album||''}`);rows.push('');}download('NaviPlayer-Duplicates.txt',rows.join('\n'),'text/plain');}

export function listeningStatistics(){const history=state.listeningHistory||[],totalSeconds=history.reduce((sum,x)=>sum+(x.seconds||0),0),aggregate=field=>Object.entries(history.reduce((m,x)=>{const key=x[field]||'Unknown';m[key]??={seconds:0,plays:0};m[key].seconds+=x.seconds||0;m[key].plays++;return m;},{})).map(([name,v])=>({name,...v})).sort((a,b)=>b.seconds-a.seconds),days=[...new Set(history.map(x=>new Date(x.at).toISOString().slice(0,10)))].sort();let longest=0,run=0,last=null;for(const day of days){const d=new Date(day+'T00:00:00Z');run=last&&d-last===86400000?run+1:1;longest=Math.max(longest,run);last=d;}const today=new Date();today.setUTCHours(0,0,0,0);const current=last&&today-last<=86400000?run:0,hours=Array(24).fill(0);for(const x of history)hours[new Date(x.at).getHours()]+=x.seconds||0;return{totalSeconds,recent:history.slice().reverse(),artists:aggregate('artist'),albums:aggregate('album'),tracks:aggregate('title'),currentStreak:current,longestStreak:longest,daysListened:days.length,peakHour:hours.indexOf(Math.max(...hours)),hours};}

export function setMetadataScanQuality(quality){state.settings.metadataScanQuality=normalizeMetadataScanQuality(quality);saveSettings();return state.settings.metadataScanQuality;}
export async function rescanSelectedMetadata(onProgress){return rescanMediaItems(selectedItems(),state.settings.metadataScanQuality,onProgress);}
export async function rescanEntireLibraryMetadata(onProgress){return rescanMediaItems(state.library,state.settings.metadataScanQuality,onProgress);}

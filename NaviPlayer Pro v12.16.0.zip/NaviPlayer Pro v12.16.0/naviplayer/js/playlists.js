import { state, savePlaylists, stableMediaKey } from './state.js';
import { basename, normalizePath, uid } from './utils.js';
import { createStream, visibleItems } from './library.js';
import { scheduleLinkedPlaylistSave } from './playlist-files.js';

export function normalizePlaylists() {
  state.playlists = (Array.isArray(state.playlists) ? state.playlists : [])
    .filter(Boolean)
    .map(playlist => ({
      ...playlist,
      id: playlist.id || uid(),
      name: String(playlist.name || 'Untitled Playlist'),
      trackKeys: [...new Set(playlist.trackKeys || [])],
      paths: [...new Set([...(playlist.paths || []), ...(playlist.trackKeys || []).map(key => { const match = String(key).match(/^file:(.+?)(?:\|\d+\|\d+)?$/); return match?.[1] || ''; }).filter(Boolean)])],
      streams: Array.isArray(playlist.streams) ? playlist.streams : [],
      tags: Array.isArray(playlist.tags) ? playlist.tags : [],
      playback: playlist.playback && typeof playlist.playback==='object' ? playlist.playback : {},
    }));
  savePlaylists();
}

export function selectedPlaylist() {
  return state.selected?.type === 'playlist'
    ? state.playlists.find(item => item.id === state.selected.key)
    : null;
}

export function createPlaylist(name = 'Untitled Playlist', tracks = []) {
  const playlist = { id: uid(), name, trackKeys: [], paths: [], streams: [], tags: [], playback: {} };
  for (const track of tracks) addTrackWithoutSaving(track, playlist);
  state.playlists.push(playlist);
  savePlaylists();
  return playlist;
}

export function addTrackWithoutSaving(track, playlist) {
  playlist.trackKeys ||= [];
  playlist.paths ||= [];
  playlist.streams ||= [];
  if (track.source === 'stream') {
    if (!playlist.streams.some(item => item.url === track.url)) {
      playlist.streams.push({ title: track.title, url: track.url });
    }
  } else {
    const key=stableMediaKey(track);if(key&&!playlist.trackKeys.includes(key))playlist.trackKeys.push(key);
    if (track.relativePath && !playlist.paths.includes(track.relativePath)) playlist.paths.push(track.relativePath);
  }
}

export function addTrackToPlaylist(track, id) {
  const playlist = state.playlists.find(item => item.id === id);
  if (!playlist) return false;
  addTrackWithoutSaving(track, playlist);
  savePlaylists();
  scheduleLinkedPlaylistSave(playlist);
  return true;
}

export function addVisibleToPlaylist(playlist) {
  for (const item of visibleItems().filter(item => item.source !== 'group')) {
    addTrackWithoutSaving(item, playlist);
  }
  savePlaylists();
  scheduleLinkedPlaylistSave(playlist);
}

export function removeTrackFromSelectedPlaylist(track) {
  const playlist=selectedPlaylist();if(!playlist||!track)return false;const before=(playlist.trackKeys||[]).length+(playlist.paths||[]).length+(playlist.streams||[]).length;
  if(track.source==='stream')playlist.streams=(playlist.streams||[]).filter(item=>item.url!==track.url);
  else{const stable=stableMediaKey(track),relative=normalizePath(track.relativePath||''),file=normalizePath(track.fileName||basename(track.relativePath||''));playlist.trackKeys=(playlist.trackKeys||[]).filter(key=>stableMediaKey(key)!==stable);playlist.paths=(playlist.paths||[]).filter(path=>{const normalized=normalizePath(path),pathFile=normalizePath(basename(path));return normalized!==relative&&pathFile!==file;});}
  const changed=before!==((playlist.trackKeys||[]).length+(playlist.paths||[]).length+(playlist.streams||[]).length);if(changed){savePlaylists();scheduleLinkedPlaylistSave(playlist);}return changed;
}

export function parseM3u(text) {
  const output = [];
  let label = '';
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF:')) {
      const comma = line.indexOf(',');
      label = comma >= 0 ? line.slice(comma + 1).trim() : '';
      continue;
    }
    if (line.startsWith('#')) continue;
    output.push({ uri: line, label });
    label = '';
  }
  return output;
}

function matchM3uEntry(entry) {
  const uri = normalizePath(entry.uri);
  const noExtension = normalizePath(entry.uri.replace(/\.[^.]+$/, ''));
  const file = normalizePath(entry.uri.split('/').pop() || entry.uri);
  const base = normalizePath(basename(entry.uri));
  if (state.indexes.path.has(uri)) return state.indexes.path.get(uri);
  if (state.indexes.pathNoExtension.has(noExtension)) return state.indexes.pathNoExtension.get(noExtension);
  for (const [indexedPath, track] of state.indexes.path) {
    if (indexedPath.endsWith(uri) || uri.endsWith(indexedPath)) return track;
  }
  let candidates = state.indexes.file.get(file);
  if (candidates?.length) return candidates[0];
  candidates = state.indexes.base.get(base);
  if (candidates?.length) return candidates[0];
  if (entry.label.includes(' - ')) {
    const [artist, ...rest] = entry.label.split(' - ');
    candidates = state.indexes.metadata.get(`${normalizePath(artist)}|||${normalizePath(rest.join(' - '))}`);
    if (candidates?.length) return candidates[0];
  }
  return null;
}

export async function importPlaylistFile(file) {
  const matched = [];
  const streams = [];
  let missed = 0;
  for (const entry of parseM3u(await file.text())) {
    const track = matchM3uEntry(entry);
    if (track) matched.push(track);
    else if (/^https?:\/\//i.test(entry.uri) && /\.m3u8($|\?)/i.test(entry.uri)) {
      streams.push({ title: entry.label || basename(entry.uri), url: entry.uri });
    } else missed += 1;
  }
  const seen = new Set();
  const unique = matched.filter(track => !seen.has(track.key) && seen.add(track.key));
  const playlist = {
    id: uid(),
    name: file.name,
    trackKeys: unique.map(track => track.key),
    paths: unique.map(track => track.relativePath).filter(Boolean),
    streams,
    tags: [],
  };
  state.playlists.push(playlist);
  savePlaylists();
  state.lastImport = unique;
  state.side = 'playlists';
  state.view = 'selected';
  state.selected = { type: 'playlist', key: playlist.id };
  state.collectionBrowse=false;
  return { playlist, matched: unique.length, streams: streams.length, missed };
}

export function serializePlaylist(playlist = selectedPlaylist()) {
  if (!playlist) return '';
  const lines = ['#EXTM3U'];
  for (const key of playlist.trackKeys || []) {
    const item=state.byKey.get(key)||state.library.find(value=>stableMediaKey(value)===stableMediaKey(key));
    if (!item) continue;
    lines.push(`#EXTINF:-1,${item.artist || item.collection || 'Local Media'} - ${item.title}`);
    lines.push(item.relativePath || item.fileName);
  }
  for (const stream of playlist.streams || []) {
    lines.push(`#EXTINF:-1,${stream.title}`);
    lines.push(stream.url);
  }
  return lines.join('\n') + '\n';
}
export function exportPlaylist(playlist = selectedPlaylist()) {
  if (!playlist) return false;
  const blob = new Blob([serializePlaylist(playlist)], { type: 'audio/x-mpegurl' });
  const anchor = document.createElement('a');
  anchor.href = URL.createObjectURL(blob);
  anchor.download = `${(playlist.name || 'playlist').replace(/[\\/:*?"<>|]+/g, '_')}.${state.settings.exportExtension || 'm3u8'}`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(anchor.href), 1000);
  return true;
}

export function setPlaylistPlaybackSettings(id,settings){const playlist=state.playlists.find(item=>item.id===id);if(!playlist)return false;playlist.playback={...(playlist.playback||{}),...settings};savePlaylists();scheduleLinkedPlaylistSave(playlist);return true;}

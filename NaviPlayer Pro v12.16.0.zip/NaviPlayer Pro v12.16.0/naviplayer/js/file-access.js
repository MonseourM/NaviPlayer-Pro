import { state } from './state.js';
import { readHandle, writeHandle, deleteHandle } from './storage.js';
import { loadDirectory } from './library.js';

const LIBRARY_HANDLE_KEY = 'persistent-library-directory';
export const supportsPersistentLibrary = () => typeof window.showDirectoryPicker === 'function';

async function permission(handle, request = false) {
  if (!handle) return 'denied';
  const descriptor = { mode: 'read' };
  try {
    const existing = await handle.queryPermission(descriptor);
    if (existing === 'granted' || !request) return existing;
    return await handle.requestPermission(descriptor);
  } catch { return 'denied'; }
}
function setStatus(status, message = '', folderName = '') {
  state.fileAccess = { supported: supportsPersistentLibrary(), status, message, folderName };
  return state.fileAccess;
}
export async function choosePersistentFolder(onProgress) {
  if (!supportsPersistentLibrary()) return setStatus('unsupported', 'Persistent folders are unavailable in this browser or embedded workspace.');
  try {
    const handle = await window.showDirectoryPicker({ mode: 'read' });
    await writeHandle(LIBRARY_HANDLE_KEY, handle);
    setStatus('scanning', 'Scanning saved folder…', handle.name);
    await loadDirectory(handle, onProgress);
    return setStatus('connected', `Connected to ${handle.name}.`, handle.name);
  } catch (error) {
    if (error?.name === 'AbortError') return setStatus('idle', 'Folder selection cancelled.');
    return setStatus('denied', error?.message || 'Folder access was denied.');
  }
}
export async function restorePersistentFolder(onProgress) {
  if (!supportsPersistentLibrary()) return setStatus('unsupported', 'Persistent folders are unavailable in this browser or embedded workspace.');
  const handle = await readHandle(LIBRARY_HANDLE_KEY);
  if (!handle) return setStatus('idle', 'No persistent folder is linked.');
  const access = await permission(handle, false);
  if (access !== 'granted') return setStatus('reconnect', `Reconnect ${handle.name} to restore the Library.`, handle.name);
  setStatus('scanning', 'Restoring saved Library…', handle.name);
  await loadDirectory(handle, onProgress);
  return setStatus('connected', `Restored ${handle.name}.`, handle.name);
}
export async function reconnectPersistentFolder(onProgress) {
  const handle = await readHandle(LIBRARY_HANDLE_KEY);
  if (!handle) return choosePersistentFolder(onProgress);
  const access = await permission(handle, true);
  if (access !== 'granted') return setStatus('denied', `Access to ${handle.name} was not granted.`, handle.name);
  setStatus('scanning', 'Reconnecting saved Library…', handle.name);
  await loadDirectory(handle, onProgress);
  return setStatus('connected', `Reconnected ${handle.name}.`, handle.name);
}
export async function rescanPersistentFolder(onProgress) {
  const handle = await readHandle(LIBRARY_HANDLE_KEY);
  if (!handle) return setStatus('idle', 'No persistent folder is linked.');
  const access = await permission(handle, false);
  if (access !== 'granted') return setStatus('reconnect', `Reconnect ${handle.name} before rescanning.`, handle.name);
  setStatus('scanning', 'Rescanning saved Library…', handle.name);
  await loadDirectory(handle, onProgress);
  return setStatus('connected', `Rescanned ${handle.name}.`, handle.name);
}
export async function forgetPersistentFolder() {
  await deleteHandle(LIBRARY_HANDLE_KEY);
  return setStatus('idle', 'Saved folder access was forgotten.');
}

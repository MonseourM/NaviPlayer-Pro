import { state, emptyIndexes } from './state.js';
import { basename, extension, normalizePath } from './utils.js';
import { createMedia } from './metadata.js';
import { isLiked,isEntityLiked } from './likes.js';
import { getWatchRecord } from './watch-progress.js';
import { applyOverride } from './metadata-overrides.js';
import { ensureVideoThumbnail } from './video-thumbnails.js';

export const AUDIO_EXTENSIONS = ['.mp3','.flac','.m4a','.aac','.ogg','.oga','.opus','.wav','.wma','.aif','.aiff','.alac'];
export const VIDEO_EXTENSIONS = ['.mp4','.m4v','.webm','.mov','.mkv','.avi','.ogv','.ogg'];
export function mediaTypeForName(name) {
  const ext = extension(name);
  if (AUDIO_EXTENSIONS.includes(ext)) return 'audio';
  if (VIDEO_EXTENSIONS.includes(ext)) return 'video';
  return null;
}
export function mediaTypeForFile(file) {
  if (String(file?.type || '').startsWith('video/')) return 'video';
  if (String(file?.type || '').startsWith('audio/')) return 'audio';
  return mediaTypeForName(file?.name || '');
}
export function isSupportedMedia(name) { return Boolean(mediaTypeForName(name)); }
export function albumKey(item) { return `album:${normalizePath(item.album)}|||${normalizePath(item.albumArtist || item.artist)}`; }
export function artistKey(item) { return `artist:${normalizePath(item.artist || item.albumArtist)}`; }
export function genreKey(item) { return `genre:${normalizePath(item.genre)}`; }
export function showKey(item) { return `show:${normalizePath(item.collection || item.album || 'Videos')}`; }
const collectionItemCache=new Map();function invalidateCollectionItemCache(){collectionItemCache.clear();}

export function indexMedia(item) {
  state.byKey.set(item.key, item);
  const relative = normalizePath(item.relativePath);
  const noExtension = normalizePath(item.relativePath.replace(/\.[^.]+$/, ''));
  const file = normalizePath(item.fileName);
  const base = normalizePath(basename(item.fileName));
  const metadata = `${normalizePath(item.artist)}|||${normalizePath(item.title)}`;
  if (relative) state.indexes.path.set(relative, item);
  if (noExtension) state.indexes.pathNoExtension.set(noExtension, item);
  for (const [map, key] of [[state.indexes.file,file],[state.indexes.base,base],[state.indexes.metadata,metadata]]) {
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
}
function addCollection(map,key,type,name,sub,coverUrl) {
  if (!map.has(key)) map.set(key,{key,type,name,sub,count:0,coverUrl});
  const group=map.get(key); group.count += 1; if (!group.coverUrl && coverUrl) group.coverUrl=coverUrl;
}
export function rebuildCollections() {
  invalidateCollectionItemCache();
  const albums=new Map(), artists=new Map(), genres=new Map(), shows=new Map();
  for (const item of state.library) {
    if (item.type === 'audio') {
      addCollection(albums,albumKey(item),'album',item.album,item.albumArtist||item.artist,item.coverUrl);
      addCollection(artists,artistKey(item),'artist',item.artist,'Artist',item.coverUrl);
      addCollection(genres,genreKey(item),'genre',item.genre,'Genre',null);
    } else {
      const name=item.collection||item.album||'Videos';
      addCollection(shows,showKey(item),'show',name,'Show / Collection',item.coverUrl);
    }
  }
  const byName=(a,b)=>(Number(state.pinnedCollections.has(b.key))-Number(state.pinnedCollections.has(a.key)))||a.name.localeCompare(b.name);
  state.collections={albums:[...albums.values()].sort(byName),artists:[...artists.values()].sort(byName),genres:[...genres.values()].sort(byName),shows:[...shows.values()].sort(byName)};
}
export async function scanDirectory(directoryHandle) {
  const output=[];
  async function walk(handle,prefix='') {
    for await (const entry of handle.values()) {
      const relativePath=prefix?`${prefix}/${entry.name}`:entry.name;
      if(entry.kind==='directory') await walk(entry,relativePath);
      else { const type=mediaTypeForName(entry.name); if(type) output.push({handle:entry,relativePath,type}); }
    }
  }
  await walk(directoryHandle); return output;
}
export function clearLibrary() {
  invalidateCollectionItemCache();
  for(const item of state.library) if(item.coverUrl?.startsWith('blob:')) URL.revokeObjectURL(item.coverUrl);
  state.library=[]; state.byKey.clear(); state.indexes=emptyIndexes(); state.collections={albums:[],artists:[],genres:[],shows:[]};
  state.queue=[]; state.queueIndex=-1; state.selected=null; state.lastImport=[];
}
export async function loadEntries(entries,maker,onProgress=()=>{},options={}) {
  if(options.replace) clearLibrary();
  const imported=[]; let processed=0;
  for(const entry of entries){
    const item=applyOverride(await maker(entry)),existingIndex=state.library.findIndex(value=>value.key===item.key);
    if(existingIndex>=0){const previous=state.library[existingIndex];if(previous.coverUrl?.startsWith('blob:')&&previous.coverUrl!==item.coverUrl)URL.revokeObjectURL(previous.coverUrl);state.library[existingIndex]=item;}else state.library.push(item);
    imported.push(item);if(item.type==='video'&&!item.coverUrl)ensureVideoThumbnail(item).then(url=>{if(url){item.coverUrl=url;window.dispatchEvent(new CustomEvent('naviplayer-thumbnail',{detail:{key:item.key}}));}});
    processed+=1;if(processed%20===0||processed===entries.length)onProgress(processed,entries.length);
  }
  state.byKey.clear();state.indexes=emptyIndexes();for(const item of state.library)indexMedia(item);
  state.library.sort((a,b)=>a.type.localeCompare(b.type)||(a.collection||a.album||'').localeCompare(b.collection||b.album||'')||((a.season||0)-(b.season||0))||((a.episode||a.trackNo||999999)-(b.episode||b.trackNo||999999))||(a.title||'').localeCompare(b.title||''));
  rebuildCollections();rebuildSearchDocuments();state.lastImport=imported;
  for(const playlist of state.playlists){playlist.paths ||= [];const resolved=playlist.paths.map(path=>state.indexes.path.get(normalizePath(path))).filter(Boolean);playlist.trackKeys=[...new Set([...(playlist.trackKeys||[]).filter(key=>state.byKey.has(key)),...resolved.map(item=>item.key)])];}
  state.queue=state.queue.map(old=>state.byKey.get(old.key)).filter(Boolean);state.queueIndex=state.queue.length?Math.max(0,Math.min(state.queueIndex,state.queue.length-1)):-1;return state.library;
}
export async function loadFiles(files,onProgress){const entries=[...files].map(file=>({file,relativePath:file.webkitRelativePath||file.name,type:mediaTypeForFile(file)})).filter(entry=>entry.type);return loadEntries(entries,entry=>createMedia(entry.file,entry.relativePath,entry.type),onProgress,{replace:false});}
export async function loadDirectory(directoryHandle,onProgress){const entries=await scanDirectory(directoryHandle);return loadEntries(entries,async entry=>{const file=await entry.handle.getFile();return createMedia(file,entry.relativePath,mediaTypeForFile(file)||entry.type);},onProgress,{replace:true});}
export function createStream(title,url) { return{key:`stream:${url}`,type:'audio',source:'stream',title:title||basename(url)||'Stream',artist:'Streaming Source',album:'HLS Stream',genre:'Stream',url}; }
export function tracksForPlaylist(id) { const playlist=state.playlists.find(item=>item.id===id); if(!playlist)return[]; return[...(playlist.trackKeys||[]).map(key=>state.byKey.get(key)).filter(Boolean),...(playlist.streams||[]).map(item=>createStream(item.title,item.url))]; }
export function itemsForCollection(type,key){const playlist=type==='playlist'?state.playlists.find(item=>item.id===key):null,playlistSignature=playlist?`${(playlist.trackKeys||[]).join('~')}|${(playlist.streams||[]).map(item=>item.url).join('~')}`:'';const cacheKey=`${state.searchVersion}|${state.library.length}|${state.playlists.length}|${type}|${key}|${playlistSignature}`;if(collectionItemCache.has(cacheKey))return collectionItemCache.get(cacheKey);let result;if(type==='album')result=state.library.filter(x=>albumKey(x)===key);else if(type==='artist')result=state.library.filter(x=>artistKey(x)===key||`artist:${normalizePath(x.albumArtist||'')}`===key);else if(type==='genre')result=state.library.filter(x=>genreKey(x)===key);else if(type==='show')result=state.library.filter(x=>showKey(x)===key).sort((a,b)=>(a.season??999)-(b.season??999)||(a.episode??999999)-(b.episode??999999)||(a.title||'').localeCompare(b.title||''));else if(type==='playlist')result=tracksForPlaylist(key);else if(type==='season'){const parts=String(key).split(':'),season=parts.pop(),show=parts.slice(1).join(':');result=itemsForCollection('show',show).filter(x=>String(x.season??'unknown')===season);}else result=[];collectionItemCache.set(cacheKey,result);return result;}
export function seasonsForShow(key){const map=new Map();for(const item of itemsForCollection('show',key)){const season=item.season??'unknown',id=`season:${key}:${season}`;if(!map.has(id))map.set(id,{key:id,type:'season',showKey:key,season,name:season==='unknown'?'Unknown Season':`Season ${season}`,sub:'Season',count:0,coverUrl:item.coverUrl||null});map.get(id).count++;}return[...map.values()].sort((a,b)=>(a.season==='unknown'?999:a.season)-(b.season==='unknown'?999:b.season));}
export function rebuildSearchDocuments(){state.searchDocuments=state.library.map(item=>({item,text:[item.title,item.artist,item.album,item.albumArtist,item.genre,item.fileName,item.relativePath,item.collection,item.season,item.episode,item.type].filter(Boolean).join(' ').toLowerCase()}));state.searchVersion++;}

export function searchAll(query,scope=state.side) {
  const normalized=query.toLowerCase(); const matches=(...values)=>values.filter(Boolean).some(value=>String(value).toLowerCase().includes(normalized));
  const media=state.searchDocuments.filter(document=>document.text.includes(normalized)).map(document=>document.item);
  const groups=[];
  for(const album of state.collections.albums)if(matches(album.name,album.sub,'album'))groups.push({...album,source:'group',title:album.name,artist:album.sub,album:'Album result'});
  for(const artist of state.collections.artists)if(matches(artist.name,'artist'))groups.push({...artist,source:'group',title:artist.name,artist:'Artist',album:'Artist result'});
  for(const genre of state.collections.genres)if(matches(genre.name,'genre'))groups.push({...genre,source:'group',title:genre.name,artist:'Genre',album:'Genre result'});
  for(const show of state.collections.shows)if(matches(show.name,'show','collection'))groups.push({...show,source:'group',title:show.name,artist:'Show',album:'Collection result'});
  for(const playlist of state.playlists)if(matches(playlist.name,'playlist',...(playlist.tags||[])))groups.push({key:playlist.id,type:'playlist',source:'group',name:playlist.name,title:playlist.name,artist:'Playlist',album:'Playlist result',sub:'Playlist',count:(playlist.trackKeys||[]).length+(playlist.streams||[]).length});
  for(const group of groups)group.entryKind='entity';for(const item of media)item.entryKind='media';const all=[...groups,...media];
  if(scope==='all')return all;if(scope==='albums')return all.filter(x=>x.type==='album');if(scope==='artists')return all.filter(x=>x.type==='artist');if(scope==='genres')return all.filter(x=>x.type==='genre');if(scope==='shows')return all.filter(x=>x.type==='show'||x.type==='video');if(scope==='playlists')return all.filter(x=>x.type==='playlist');return all;
}
export function entityItemsForRoot(root=state.side){if(root==='albums')return state.collections.albums;if(root==='artists')return state.collections.artists;if(root==='genres')return state.collections.genres;if(root==='shows')return state.collections.shows;if(root==='playlists')return state.playlists.map(playlist=>({key:playlist.id,type:'playlist',name:playlist.name,sub:'Playlist',count:(playlist.trackKeys||[]).length+(playlist.streams||[]).length,coverUrl:null}));return[];}
let allFeedCache={signature:'',items:[]};export function unifiedAllFeed(query=''){const signature=`${state.searchVersion}|${state.collections.albums.length}|${state.collections.artists.length}|${state.collections.genres.length}|${state.collections.shows.length}|${state.playlists.length}|${state.library.length}`;if(allFeedCache.signature!==signature){const entities=[...state.collections.albums,...state.collections.artists,...state.collections.genres,...state.collections.shows,...entityItemsForRoot('playlists')].map(item=>({...item,source:'group',entryKind:'entity',title:item.name,artist:item.sub,allType:item.type}));for(const item of state.library){item.entryKind='media';item.allType=item.type==='video'?(item.episode?'episode':'video'):'song';}allFeedCache={signature,items:[...entities,...state.library]};}const terms=String(query).trim().toLowerCase();if(!terms)return allFeedCache.items;return allFeedCache.items.filter(item=>[item.name,item.title,item.sub,item.artist,item.album,item.collection,item.genre,item.fileName].filter(Boolean).some(value=>String(value).toLowerCase().includes(terms)));}
export function visibleItems() {
  let items;
  if(state.view==='selected'&&state.selected){const{type,key}=state.selected;items=itemsForCollection(type,key);}
  else if(state.side==='all')items=unifiedAllFeed(state.search.trim());
  else if(state.search.trim()) items=searchAll(state.search.trim(),state.side);
  else if(state.view==='matches') items=state.lastImport;
  else if(['albums','artists','genres','shows','playlists'].includes(state.side))items=entityItemsForRoot(state.side).map(item=>({...item,source:'group',title:item.name,artist:item.sub,allType:item.type}));
  else items=state.library;
  const sorters={titleAsc:(a,b)=>(a.title||a.name||'').localeCompare(b.title||b.name||''),titleDesc:(a,b)=>(b.title||b.name||'').localeCompare(a.title||a.name||''),artist:(a,b)=>(a.artist||'').localeCompare(b.artist||'')||(a.title||'').localeCompare(b.title||''),album:(a,b)=>(a.album||'').localeCompare(b.album||'')||(a.trackNo||999999)-(b.trackNo||999999),modified:(a,b)=>(b.modified||0)-(a.modified||0),track:(a,b)=>(a.trackNo||999999)-(b.trackNo||999999)||(a.title||'').localeCompare(b.title||''),episode:(a,b)=>(a.season??999)-(b.season??999)||(a.episode??999999)-(b.episode??999999)||(a.title||'').localeCompare(b.title||''),path:(a,b)=>(a.relativePath||'').localeCompare(b.relativePath||'')};
  if(state.sortMode!=='default'&&sorters[state.sortMode])items=[...items].sort(sorters[state.sortMode]);
  if (state.libraryFilter === 'recent') items = [...items].sort((a, b) => (b.modified || 0) - (a.modified || 0));
  else if (state.libraryFilter === 'continue') items = items.filter(item => item.type === 'video' && getWatchRecord(item)?.position > 10 && !getWatchRecord(item)?.watched);
  else if (state.libraryFilter === 'unwatched') items = items.filter(item => item.type === 'video' && !getWatchRecord(item)?.watched);
  else if (state.libraryFilter === 'liked') items = items.filter(item => item.source !== 'group' && isLiked(item));
  else if (state.libraryFilter === 'likedAudio') items = items.filter(item => item.type === 'audio' && isLiked(item));
  else if (state.libraryFilter === 'likedVideo') items = items.filter(item => item.type === 'video' && isLiked(item));
  if(state.libraryFilter==='likedEntities')items=items.filter(x=>x.source==='group'&&isEntityLiked(x.key));
  if(state.mediaFilter==='audio')return items.filter(item=>item.type==='audio'||['album','artist','genre','playlist'].includes(item.type));
  if(state.mediaFilter==='video')return items.filter(item=>item.type==='video'||['show','playlist'].includes(item.type));
  return items;
}

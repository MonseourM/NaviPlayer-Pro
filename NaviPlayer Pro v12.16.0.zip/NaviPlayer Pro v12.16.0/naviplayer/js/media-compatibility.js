import {state} from './state.js';import {mediaCompatibility} from './playback.js';
export function compatibilityReport(){return state.library.map(item=>({item,status:mediaCompatibility(item)})).filter(x=>x.status.status==='unsupported'||x.status.status==='unknown');}
export function conversionRuntimeStatus(){return globalThis.FFmpeg?{available:true,message:'A conversion runtime is available.'}:{available:false,message:'No conversion runtime is loaded. NaviPlayer can diagnose files, but conversion is unavailable in this build.'};}
export async function convertForBrowser(item){const runtime=conversionRuntimeStatus();if(!runtime.available)throw new Error(runtime.message);throw new Error('The detected conversion runtime does not expose a configured NaviPlayer adapter.');}

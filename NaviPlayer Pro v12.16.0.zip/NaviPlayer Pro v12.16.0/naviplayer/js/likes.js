import {state,saveLikedMedia,saveLikedEntities,stableMediaKey} from './state.js';
export function isLiked(value){const key=stableMediaKey(value);return Boolean(key&&state.likedMedia.has(key));}
export function toggleLiked(value){const key=stableMediaKey(value);if(!key)return false;state.likedMedia.has(key)?state.likedMedia.delete(key):state.likedMedia.add(key);saveLikedMedia();return state.likedMedia.has(key);}
export function isEntityLiked(key){return Boolean(key&&state.likedEntities.has(key));}
export function toggleEntityLiked(key){if(!key)return false;state.likedEntities.has(key)?state.likedEntities.delete(key):state.likedEntities.add(key);saveLikedEntities();return state.likedEntities.has(key);}

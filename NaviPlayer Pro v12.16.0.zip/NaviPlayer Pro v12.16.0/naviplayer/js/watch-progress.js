import { state, saveWatchState, stableMediaKey } from './state.js';

const SAVE_INTERVAL_SECONDS = 5;
let lastSavedSecond = -1;
let lastItemKey = null;

export function getWatchRecord(itemOrKey) {
  const key=stableMediaKey(itemOrKey);
  return key ? state.watchState[key] || null : null;
}

export function isWatched(itemOrKey) {
  return Boolean(getWatchRecord(itemOrKey)?.watched);
}

export function setWatched(itemOrKey, watched = true) {
  const item=typeof itemOrKey==='string'?state.byKey.get(itemOrKey):itemOrKey;const key=stableMediaKey(itemOrKey);
  if(!key||!item||item.type!=='video')return false;
  const current = getWatchRecord(item) || {};
  state.watchState[key]={
    ...current,
    watched: Boolean(watched),
    updatedAt: Date.now(),
    position: watched ? Math.max(current.position || 0, current.duration || 0) : current.position || 0,
  };
  saveWatchState();
  return state.watchState[key].watched;
}

export function clearWatchProgress(itemOrKey) {
  const key=stableMediaKey(itemOrKey);
  if (!key) return;
  delete state.watchState[key];
  saveWatchState();
}

export function recordWatchProgress(item, position, duration, force = false) {
  if (!item?.key || item.type !== 'video' || !Number.isFinite(position) || !Number.isFinite(duration) || duration <= 0) return;
  const second = Math.floor(position);
  const key=stableMediaKey(item);if(!key)return;if(lastItemKey!==key){lastItemKey=key; lastSavedSecond = -1; }
  if (!force && second - lastSavedSecond < SAVE_INTERVAL_SECONDS) return;
  lastSavedSecond = second;
  const watched = position / duration >= 0.9 || duration - position <= 120;
  state.watchState[key]={
    position,
    duration,
    watched,
    updatedAt: Date.now(),
  };
  saveWatchState();
}

export function resumablePosition(item) {
  const record = getWatchRecord(item);
  if (!record || record.watched || !Number.isFinite(record.position)) return 0;
  return record.position > 10 ? record.position : 0;
}

export function continueWatchingItems() {
  return state.library
    .filter(item => item.type === 'video')
    .filter(item => {
      const record = getWatchRecord(item);
      return record && !record.watched && record.position > 10;
    })
    .sort((a, b) => (getWatchRecord(b)?.updatedAt || 0) - (getWatchRecord(a)?.updatedAt || 0));
}

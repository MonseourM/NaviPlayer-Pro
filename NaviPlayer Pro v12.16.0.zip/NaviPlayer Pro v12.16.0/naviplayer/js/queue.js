import { state } from './state.js';
import { uid } from './utils.js';
import { syncQueueIndex, currentItem, stopPlayback, loadQueueIndex } from './playback.js';

function notifyQueue(){window.dispatchEvent(new CustomEvent('naviplayer-queue-changed'));}
export function queueCount() { return state.queue.length; }
export function clearQueue(){stopPlayback();state.queue=[];state.queueIndex=-1;state.inspected=null;state.contextItem=null;state.opened=null;notifyQueue();}
export function addToQueue(item){if(!item||item.source==='group')return false;const wasEmpty=state.queue.length===0;let index=state.queue.findIndex(value=>value.key===item.key);if(index<0){state.queue.push(item);index=state.queue.length-1;}if(wasEmpty)loadQueueIndex(index,Boolean(state.settings.autoplayQueued));else syncQueueIndex();notifyQueue();return true;}
export function playNext(item) {
  if (!item || item.source === 'group') return false;
  syncQueueIndex();
  const current=currentItem();
  if(current?.key===item.key)return false;
  let existing=state.queue.findIndex(value=>value.key===item.key);
  if(existing>=0)state.queue.splice(existing,1);
  syncQueueIndex();
  const target=Math.max(0,state.queueIndex+1);
  state.queue.splice(target,0,item);
  syncQueueIndex();notifyQueue();return true;
}
export function playNextMany(items){
  syncQueueIndex();const current=currentItem(),ordered=[];
  for(const item of items||[]){if(!item||item.source==='group'||item.key===current?.key||ordered.some(value=>value.key===item.key))continue;ordered.push(item);}
  if(!ordered.length)return 0;
  const keys=new Set(ordered.map(item=>item.key));state.queue=state.queue.filter(item=>!keys.has(item.key));syncQueueIndex();
  const target=Math.max(0,state.queueIndex+1);state.queue.splice(target,0,...ordered);syncQueueIndex();notifyQueue();return ordered.length;
}
export function moveQueueItemTo(index,target){
  if(!Number.isInteger(index)||!Number.isInteger(target)||index<0||index>=state.queue.length)return false;
  target=Math.max(0,Math.min(target,state.queue.length-1));if(index===target)return false;
  const [item]=state.queue.splice(index,1);state.queue.splice(target,0,item);syncQueueIndex();notifyQueue();return true;
}
export function removeQueueIndex(index){if(!Number.isInteger(index)||index<0||index>=state.queue.length)return;const removed=state.queue[index],isCurrent=removed?.key===currentItem()?.key;state.queue.splice(index,1);if(isCurrent){stopPlayback();state.inspected=null;state.contextItem=null;}else{if(state.inspected?.key===removed?.key){state.inspected=null;state.contextItem=null;}syncQueueIndex();}if(!state.queue.length){stopPlayback();state.queueIndex=-1;state.inspected=null;state.contextItem=null;}notifyQueue();}
export function moveQueueItem(index, direction) {
  const next = index + direction;
  if (index < 0 || next < 0 || index >= state.queue.length || next >= state.queue.length) return;
  const currentKey = state.queue[state.queueIndex]?.key;
  [state.queue[index], state.queue[next]] = [state.queue[next], state.queue[index]];
  if(currentKey)state.queueIndex=state.queue.findIndex(item=>item.key===currentKey);notifyQueue();
}
export function exportQueue() {
  const lines = ['#EXTM3U'];
  for (const item of state.queue) {
    lines.push(`#EXTINF:-1,${item.artist || item.collection || 'Local Media'} - ${item.title}`);
    lines.push(item.relativePath || item.fileName || item.url || '');
  }
  const blob = new Blob([lines.join('\n') + '\n'], { type: 'audio/x-mpegurl' });
  const anchor = document.createElement('a');
  anchor.href = URL.createObjectURL(blob);
  anchor.download = `NaviPlayer-Queue-${uid()}.m3u8`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(anchor.href), 1000);
}

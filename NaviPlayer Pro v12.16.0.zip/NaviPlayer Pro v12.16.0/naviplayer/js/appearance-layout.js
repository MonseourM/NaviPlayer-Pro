import { state, saveSettings, saveWallpaperData } from './state.js';

const clamp=(value,min,max)=>Math.min(max,Math.max(min,value));
const root=document.documentElement;
let wallpaperUrl=null;

export function applyAppearance(){
  const settings=state.settings;settings.compactRows=false;
  const resolvedMode=settings.colorMode==='system'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):settings.colorMode;
  document.body.dataset.density=settings.density||'comfortable';
  document.body.dataset.theme=settings.themePreset||'purple';
  document.body.dataset.aesthetic=settings.aesthetic||'default';
  const palette={purple:['#8b5cf6','#c4b5fd'],blue:['#3b82f6','#93c5fd'],cyan:['#06b6d4','#67e8f9'],green:['#22c55e','#86efac'],amber:['#f59e0b','#fcd34d'],orange:['#f97316','#fdba74'],rose:['#fb7185','#fda4af'],red:['#ef4444','#fca5a5']};const locked=['spotify','youtube'].includes(settings.aesthetic);if(!locked){const colors=settings.themePreset==='custom'?[settings.customAccent,`color-mix(in srgb, ${settings.customAccent} 55%, white)`]:(palette[settings.themePreset]||palette.purple);document.body.style.setProperty('--accent',colors[0]);document.body.style.setProperty('--accent2',colors[1]);document.body.style.setProperty('--soft',`color-mix(in srgb, ${colors[0]} 22%, var(--panel))`);}else{document.body.style.removeProperty('--accent');document.body.style.removeProperty('--accent2');document.body.style.removeProperty('--soft');}
  document.body.dataset.colorMode=resolvedMode;
  document.body.dataset.mobilePage=settings.mobilePage||'library';
  document.body.dataset.workspacePreference=settings.workspaceLayout||'automatic';
  document.body.dataset.workspaceLayout=settings.resolvedWorkspaceLayout||'desktop';
  document.body.classList.toggle('dark',resolvedMode==='dark');
  document.body.classList.toggle('tvMode',Boolean(settings.tvMode));
  document.body.classList.remove('compactRows');
  document.body.classList.toggle('hideBranding',settings.showBranding===false);
  const video=document.getElementById('video');if(video)video.controls=!settings.tvMode;
  root.style.setProperty('--right-width',`${settings.rightWidth||400}px`);
  root.style.setProperty('--browse-context-width',`${settings.browseContextWidth||300}px`);
  root.style.setProperty('--playback-context-width',`${settings.playbackContextWidth||380}px`);
  root.style.setProperty('--wallpaper-blur',`${settings.wallpaperBlur??8}px`);
  root.style.setProperty('--wallpaper-brightness',String((settings.wallpaperBrightness??75)/100));
  if(settings.themePreset==='custom'&&settings.customAccent){root.style.setProperty('--accent',settings.customAccent);root.style.setProperty('--accent2',`color-mix(in srgb, ${settings.customAccent} 55%, white)`);root.style.setProperty('--soft',`color-mix(in srgb, ${settings.customAccent} 22%, var(--panel))`);}else{root.style.removeProperty('--accent');root.style.removeProperty('--accent2');root.style.removeProperty('--soft');}
  root.style.setProperty('--wallpaper-tint',String((settings.wallpaperTint??30)/100));
  for(const [key,css,fallback] of [['panelOpacity','--panel-opacity',96],['libraryOpacity','--library-opacity',settings.panelOpacity??96],['contextOpacity','--context-opacity',settings.panelOpacity??96],['navigationOpacity','--navigation-opacity',settings.panelOpacity??96],['menuOpacity','--menu-opacity',98],['windowOpacity','--window-opacity',98],['cardOpacity','--card-opacity',96],['rowOpacity','--row-opacity',settings.cardOpacity??96],['queueOpacity','--queue-opacity',settings.cardOpacity??96],['statusOpacity','--status-opacity',98],['footerOpacity','--footer-opacity',98],['controlOpacity','--control-opacity',100],['dockOpacity','--dock-opacity',settings.panelOpacity??96]])root.style.setProperty(css,String((settings[key]??fallback)/100));
  if(settings.wallpaper){
    document.body.classList.add('hasWallpaper');
    root.style.setProperty('--wallpaper-image',`url("${settings.wallpaper.replaceAll('"','%22')}")`);
  }else{
    document.body.classList.remove('hasWallpaper');
    root.style.removeProperty('--wallpaper-image');
  }
}

function pointerGutter(element,onDelta){
  element.addEventListener('pointerdown',event=>{
    if(event.button!==0)return;
    event.preventDefault();
    element.setPointerCapture(event.pointerId);
    element.classList.add('dragging');
    const startX=event.clientX,startY=event.clientY;
    const move=next=>onDelta(next.clientX-startX,next.clientY-startY,false);
    const end=next=>{onDelta(next.clientX-startX,next.clientY-startY,true);element.classList.remove('dragging');element.releasePointerCapture(event.pointerId);element.removeEventListener('pointermove',move);element.removeEventListener('pointerup',end);element.removeEventListener('pointercancel',end);};
    element.addEventListener('pointermove',move);element.addEventListener('pointerup',end);element.addEventListener('pointercancel',end);
  });
}
function keyboardGutter(element,onStep){
  element.addEventListener('keydown',event=>{
    const horizontal=element.getAttribute('aria-orientation')==='horizontal';
    const negative=horizontal?event.key==='ArrowLeft':event.key==='ArrowUp';
    const positive=horizontal?event.key==='ArrowRight':event.key==='ArrowDown';
    if(!negative&&!positive&&event.key!=='Home'&&event.key!=='End')return;
    event.preventDefault();onStep(negative?-16:positive?16:event.key==='Home'?-9999:9999);
  });
}
export function initializeLayout(){
  const right=document.getElementById('rightGutter');
  const main=document.querySelector('.main');
  if(right&&main){
    const specForLayout=()=>{
      const layout=document.body.dataset.workspaceLayout||state.settings.resolvedWorkspaceLayout||'desktop';
      if(layout==='compact')return{layout,key:'compactContextWidth',css:'--compact-context-width',min:280,max:460,gutter:10,minMain:420};
      if(layout==='browse')return{layout,key:'browseContextWidth',css:'--browse-context-width',min:240,max:420,gutter:10,minMain:620};
      if(layout==='playback')return{layout,key:'playbackContextWidth',css:'--playback-context-width',min:300,max:520,gutter:10,minMain:0};
      return{layout:'desktop',key:'rightWidth',css:'--right-width',min:320,max:680,gutter:14,minMain:520};
    };
    const isCollapsed=spec=>spec.layout==='browse'&&document.body.classList.contains('browseContextCollapsed')||spec.layout==='playback'&&document.body.classList.contains('playbackContextCollapsed');
    const applyWidth=(value,commit=false)=>{
      const spec=specForLayout();
      if(spec.layout==='mobile'||isCollapsed(spec))return Number(state.settings[spec.key]||400);
      const maxFromViewport=Math.max(spec.min,main.getBoundingClientRect().width-spec.minMain-spec.gutter);
      const next=clamp(Number(value)||Number(state.settings[spec.key])||400,spec.min,Math.min(spec.max,maxFromViewport));
      root.style.setProperty(spec.css,`${next}px`);
      /* Inline !important is deliberate: historical layout layers also use !important. */
      main.style.setProperty('grid-template-columns',`minmax(${spec.minMain}px,1fr) ${spec.gutter}px ${next}px`,'important');
      right.setAttribute('aria-valuemin',String(spec.min));
      right.setAttribute('aria-valuemax',String(Math.min(spec.max,Math.round(maxFromViewport))));
      right.setAttribute('aria-valuenow',String(Math.round(next)));
      if(commit){state.settings[spec.key]=next;saveSettings();window.dispatchEvent(new CustomEvent('naviplayer-layout-resized',{detail:{layout:spec.layout,width:next}}));}
      return next;
    };
    const restoreCurrentWidth=()=>{const spec=specForLayout();if(spec.layout==='mobile'||isCollapsed(spec)){main.style.removeProperty('grid-template-columns');return;}applyWidth(state.settings[spec.key]||400,false);};
    right.addEventListener('pointerdown',event=>{
      const spec=specForLayout();
      if(event.button!==0||spec.layout==='mobile'||isCollapsed(spec))return;
      event.preventDefault();event.stopPropagation();
      const startX=event.clientX;
      const startWidth=document.getElementById('rightPane')?.getBoundingClientRect().width||Number(state.settings[spec.key])||400;
      let lastX=startX,frame=0,finished=false;
      document.body.classList.add('resizingContext');right.classList.add('dragging');
      try{right.setPointerCapture?.(event.pointerId);}catch{}
      const flush=()=>{frame=0;applyWidth(startWidth-(lastX-startX),false);};
      const move=e=>{if(!Number.isFinite(e.clientX))return;lastX=e.clientX;if(!frame)frame=requestAnimationFrame(flush);};
      const end=e=>{if(finished)return;finished=true;if(Number.isFinite(e?.clientX))lastX=e.clientX;if(frame){cancelAnimationFrame(frame);frame=0;}applyWidth(startWidth-(lastX-startX),true);right.classList.remove('dragging');document.body.classList.remove('resizingContext');try{right.releasePointerCapture?.(event.pointerId);}catch{}right.removeEventListener('pointermove',move);right.removeEventListener('pointerup',end);right.removeEventListener('pointercancel',end);window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',end,true);window.removeEventListener('blur',end);};
      right.addEventListener('pointermove',move);right.addEventListener('pointerup',end);right.addEventListener('pointercancel',end);window.addEventListener('pointermove',move,true);window.addEventListener('pointerup',end,true);window.addEventListener('blur',end,{once:true});
    });
    keyboardGutter(right,step=>{const spec=specForLayout();applyWidth((Number(state.settings[spec.key])||400)-step,true);});
    right.addEventListener('dblclick',()=>{const spec=specForLayout(),defaults={rightWidth:400,compactContextWidth:340,browseContextWidth:300,playbackContextWidth:380};applyWidth(defaults[spec.key],true);});
    window.addEventListener('resize',()=>requestAnimationFrame(restoreCurrentWidth));
    window.addEventListener('naviplayer-workspace-changed',()=>requestAnimationFrame(restoreCurrentWidth));
    new MutationObserver(()=>requestAnimationFrame(restoreCurrentWidth)).observe(document.body,{attributes:true,attributeFilter:['data-workspace-layout','class']});
    requestAnimationFrame(restoreCurrentWidth);
  }
  document.querySelectorAll('[data-mobile-page]').forEach(button=>button.addEventListener('click',()=>{state.settings.mobilePage=button.dataset.mobilePage;saveSettings();applyAppearance();document.querySelectorAll('[data-mobile-page]').forEach(item=>item.classList.toggle('active',item===button));}));
}
export function setAppearanceValue(key,value){state.settings[key]=value;saveSettings();applyAppearance();}
export function loadWallpaper(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=async()=>{await saveWallpaperData(String(reader.result));applyAppearance();resolve();};reader.onerror=()=>reject(reader.error);reader.readAsDataURL(file);});}
export async function clearWallpaper(){await saveWallpaperData('');applyAppearance();}

export function setTvMode(enabled){state.settings.tvMode=Boolean(enabled);saveSettings();applyAppearance();}

export function resetLayout(){state.settings.rightWidth=400;saveSettings();applyAppearance();}

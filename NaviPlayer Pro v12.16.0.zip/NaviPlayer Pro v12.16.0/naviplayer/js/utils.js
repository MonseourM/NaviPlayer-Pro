export const $ = id => document.getElementById(id);

export function extension(name = '') {
  const index = String(name).lastIndexOf('.');
  return index >= 0 ? String(name).slice(index).toLowerCase() : '';
}

export function normalizePath(value = '') {
  return String(value)
    .replace(/\\/g, '/')
    .replace(/^\/+|^\.\//g, '')
    .trim()
    .toLowerCase();
}

export function basename(value = '') {
  const file = String(value).split('/').pop().split('\\').pop();
  const index = file.lastIndexOf('.');
  return index >= 0 ? file.slice(0, index) : file;
}

export function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function initials(value = '') {
  const parts = String(value).trim().split(/\s+/).filter(Boolean).slice(0, 2);
  return parts.length ? parts.map(part => part[0].toUpperCase()).join('') : '♪';
}

export function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
}

export function uid() {
  return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function shuffle(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const other = Math.floor(Math.random() * (index + 1));
    [result[index], result[other]] = [result[other], result[index]];
  }
  return result;
}

export function smartShuffle(items){
  const pool=[...items],result=[];let lastArtist='',lastAlbum='';
  while(pool.length){const candidates=pool.map((item,index)=>({item,index,score:(String(item.artist||'')===lastArtist?3:0)+(String(item.album||'')===lastAlbum?2:0)+Math.random()})).sort((a,b)=>a.score-b.score);const pick=candidates[0];pool.splice(pick.index,1);result.push(pick.item);lastArtist=String(pick.item.artist||'');lastAlbum=String(pick.item.album||'');}
  return result;
}
